export interface dummy{
    nama: string;
}